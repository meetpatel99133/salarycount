package com.example.salarycount;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    // define name for edittext and button
    EditText etsalary,ettaxrate,netamount,biweekly,taxrate;
    Button btnsalary,btnreset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //conenct object with the textview and button.
        etsalary = findViewById(R.id.salary);
        ettaxrate = findViewById(R.id.taxrate);
        netamount = findViewById(R.id.netamount);
        biweekly = findViewById(R.id.biweekly);
        taxrate = findViewById(R.id.tax);
        btnsalary = findViewById(R.id.count);
        btnreset = findViewById(R.id.clr);
        btnsalary.setOnClickListener(this);
        btnreset.setOnClickListener(this);



    }
    // When user click this button this onclick method with run
    @Override
    public void onClick(View v) {
        if (!etsalary.getText().toString().equals("")){
            //fatch salary which user insert
            double  salaray1 = Double.parseDouble(etsalary.getText().toString());
            //Give 12 months salary
            double  anusal = salaray1 * 12;
            double  tax = 0.0;
            //double  = 0.0;
            if (anusal <=  30000){
                tax =  anusal;
                taxrate.setText(String.valueOf(0));
            }else if (anusal > 50000 && anusal <= 70000){
                tax = anusal * 0.17;
                taxrate.setText(String.valueOf(17));
            }else if (anusal > 70000 && anusal <= 90000){
                tax = anusal * 0.23;
                taxrate.setText(String.valueOf(23));
            }else  if (anusal > 90000){
                tax = anusal * 0.27;
                taxrate.setText(String.valueOf(27));
            }
            // show Tax rate
            ettaxrate.setText(String.format("%.2f",tax));
            double exactsalaray = anusal - tax ;
            // Display net salary
            netamount.setText(String.format("%.2f",exactsalaray));
            double byweeksalaray = exactsalaray / 26;
            //Display weekly salary
            biweekly.setText(String.format("%.2f",byweeksalaray));


        }
        else {
            Toast.makeText(getApplicationContext(),"You didn't enter anything, Please enter salary",Toast.LENGTH_LONG).show();
        }
        btnreset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // reset everything
                etsalary.setText("");
                taxrate.setText("");
                ettaxrate.setText("");
                netamount.setText("");
                biweekly.setText("");
            }
        });


    }
}